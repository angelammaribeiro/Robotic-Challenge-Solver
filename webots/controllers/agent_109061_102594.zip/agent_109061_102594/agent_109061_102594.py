"""sample2 controller."""

# You may need to import some classes of the controller module. Ex:
#  from controller import Robot, Motor, DistanceSensor
from controller import Robot
import math
from gridMap import GridMap
from intersection import Intersection

sensor_angles = [
    math.pi/2,    # ps0
    math.pi/4,    # ps1
    0,            # ps2
    -math.pi/4,   # ps3
    -math.pi/2,   # ps4
    -3*math.pi/4, # ps5
    math.pi,      # ps6
    3*math.pi/4   # ps7
]

THRESHOLD_DISTANCE = 120.0  # Distância para detetar obstáculos

def run_robot(robot):

    # Initialize
    grid_map = GridMap()

    intersections = []
    node_id_counter = 0
    intersection_detected = False
    free_directions = 0

    # Initialize timestep and speed
    timestep = int(robot.getBasicTimeStep())
    max_speed = 6.28

    # Initialize motors
    left_motor = robot.getDevice('left wheel motor')
    right_motor = robot.getDevice('right wheel motor')

    left_motor.setPosition(float('inf'))
    right_motor.setPosition(float('inf'))

    left_motor.setVelocity(0.0)
    right_motor.setVelocity(0.0)

    # Initialize sensors
    # Initialize GPS
    gps = robot.getDevice('gps')
    gps.enable(timestep)

    # Initialize distance sensors
    num_dist_sensors = 8  # Number of distance sensors
    dist_sensors = [robot.getDevice('ps' + str(x)) for x in range(num_dist_sensors)]
    for sensor in dist_sensors:
        sensor.enable(timestep)

    # Initialize camera
    camera = robot.getDevice('camera')
    camera.enable(timestep)

    # Initialize compass
    compass = robot.getDevice('compass')
    compass.enable(timestep)

    # Main loop:
    # - perform simulation steps until Webots is stopping the controller
    while robot.step(timestep) != -1:
        # Read sensor values
        gps_values = gps.getValues()  # Get GPS coordinates [x, y, z]

        if grid_map.x0 is None:
            grid_map.initialize_origin(gps_values[0], gps_values[2])

        compass_values = compass.getValues()  # Get compass values
        dist_sensor_values = [sensor.getValue() for sensor in dist_sensors]  # Get distance sensor values

        localization = (gps_values[0], gps_values[2])  # Use x and z for localization

        yaw = math.atan2(compass_values[0], compass_values[2])

        i, j = grid_map.world_to_grid(localization[0], localization[1])
        grid_map.set_cell_state(i, j, 1)  # Marca célula como livre
        current_orientation = yaw #keeps track of orientation
        
        # Print sensor information
        print("GPS coordinates [x, y, z]:", gps_values)
        print("Compass values:", compass_values)
        print("Distance sensors:", dist_sensor_values)
        print("Custom data:", robot.getCustomData())

        # Chama a função para projetar dados dos sensores no grid
        project_sensor_data_to_grid(grid_map, dist_sensors, localization[0], localization[1], yaw)

        if grid_map.get_cell_state(i-1, j) == 1:
            free_directions += 1
        if grid_map.get_cell_state(i+1, j) == 1:
            free_directions += 1
        if grid_map.get_cell_state(i, j-1) == 1:
            free_directions += 1
        if grid_map.get_cell_state(i, j+1) == 1:
            free_directions += 1

        if free_directions > 2:
            intersection_detected = True

        
        if intersection_detected == True:
            intersection = Intersection(
                id=node_id_counter,
                map_coord=(i, j),
                world_pos=(localization[0], localization[1]),
                heading_options=['N', 'E', 'S', 'W']  # Example headings
            )
            intersections.append(intersection)
            node_id_counter += 1
            intersection_detected = False  # Reset flag after recording

        # Set motor velocities
        right_motor.setVelocity(0.25 * max_speed)
        left_motor.setVelocity(0.25 * max_speed)

    # Enter here exit cleanup code.

def project_sensor_data_to_grid(grid_map, dist_sensors, x, z, yaw):
    for idx, sensor in enumerate(dist_sensors):
        d = sensor.getValue()
        angle = yaw + sensor_angles[idx]
        x_obst = x + d * math.cos(angle)
        z_obst = z + d * math.sin(angle)
        i, j = grid_map.world_to_grid(x_obst, z_obst)
        if d < THRESHOLD_DISTANCE:
            grid_map.set_cell_state(i, j, 2)  # Marca como OCCUPIED
        else:
            grid_map.set_cell_state(i, j, 1)  # Marca como FREE

if __name__ == '__main__' :
    my_robot = Robot()
    run_robot(my_robot)
